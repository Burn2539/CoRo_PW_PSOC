/****************************************************************************
*
* Project Name		: PSoC CapSense 2 BLE
*
* File Name			: main.c
* Version 			: 1.0
*
* Device Used		: CY8C4247LQI-BL483
* Software Used		: PSoC Creator 3.3
* Compiler    		: ARM GCC 4.8.4, ARM MDK Generic
* Related Hardware	: CY8CKIT-042-BLE Bluetooth Low Energy Pioneer Kit 
*
* Owner             : A. BERNIER
*
*****************************************************************************
*
* Hardware connection required for testing:
* CapSense      - P2[1], P2[2], P2[3], P2[4], P2[5] 
* Cmod pin      - P4[0] (hard-wired in the PSoC 4 BLE Module)
* R-G-B LED 	- P2[6], P3[6] and P3[7] (hard-wired on the BLE Pioneer kit)
*
*****************************************************************************/


/*****************************************************************************
* Included headers
*****************************************************************************/
#include <project.h>


/*****************************************************************************
* Function Declarations
*****************************************************************************/
void InitializeSystem(void);


/*****************************************************************************
* Function Name: main()
******************************************************************************
* Summary:
*   Central function which controls the application flow.
*
* Parameters:
*   None.
*
* Return:
*   None.
*
* Note:
*
*****************************************************************************/
int main()
{
    InitializeSystem();
    
    
}


/*****************************************************************************
* Function Name: InitializeSystem()
******************************************************************************
* Summary:
*   Initialize everything here.
*
* Parameters:
*   None.
*
* Return:
*   None.
*
* Note:
*
*****************************************************************************/
void InitializeSystem(void)
{
    
}